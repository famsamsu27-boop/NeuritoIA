"""
Laboratorio de Red Neuronal: Comer / Dormir / Jugar (/ Bañarse)

App de escritorio (Tkinter + NumPy) basada en tu script de experimentos.
Ejecutar:  python app_red_neuronal.py
Requisitos: Python 3.8+  y  numpy   (pip install numpy)
"""

import queue
import threading
import tkinter as tk
from tkinter import ttk

import numpy as np

ACCIONES = ["Comer", "Dormir", "Jugar"]
ACCIONES_4 = ["Comer", "Dormir", "Jugar", "Bañarse"]


# ==================================================
# FUNCIONES DE LA RED NEURONAL
# ==================================================

def relu(x):
    return np.maximum(0, x)


def softmax(x):
    exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
    return exp_x / np.sum(exp_x, axis=1, keepdims=True)


def crear_datos(n, cuatro_acciones=False):
    X = np.random.rand(n, 4 if cuatro_acciones else 3)

    if cuatro_acciones:
        necesidades = np.column_stack((
            X[:, 0],       # Hambre
            1 - X[:, 1],   # Cansancio
            X[:, 2],       # Aburrimiento
            X[:, 3],       # Suciedad
        ))
    else:
        necesidades = np.column_stack((
            X[:, 0],
            1 - X[:, 1],
            X[:, 2],
        ))

    y = np.argmax(necesidades, axis=1)
    return X, y


def entrenar(neuronas=6, epocas=1200, tasa=0.1, cuatro_acciones=False):
    np.random.seed(42)  # resultados reproducibles en cada ejecución
    X, y = crear_datos(3000, cuatro_acciones)
    X_test, y_test = crear_datos(1000, cuatro_acciones)

    entradas = X.shape[1]
    salidas = 4 if cuatro_acciones else 3
    rng = np.random.default_rng(42)

    W1 = rng.normal(0, 0.5, (entradas, neuronas))
    b1 = np.zeros((1, neuronas))
    W2 = rng.normal(0, 0.5, (neuronas, salidas))
    b2 = np.zeros((1, salidas))

    for _ in range(epocas):
        z1 = X @ W1 + b1
        h = relu(z1)
        p = softmax(h @ W2 + b2)

        n = len(X)
        delta2 = p.copy()
        delta2[np.arange(n), y] -= 1
        delta2 /= n

        grad_W2 = h.T @ delta2
        grad_b2 = np.sum(delta2, axis=0, keepdims=True)

        delta1 = (delta2 @ W2.T) * (z1 > 0)
        grad_W1 = X.T @ delta1
        grad_b1 = np.sum(delta1, axis=0, keepdims=True)

        W1 -= tasa * grad_W1
        b1 -= tasa * grad_b1
        W2 -= tasa * grad_W2
        b2 -= tasa * grad_b2

        if not np.all(np.isfinite(W1)) or not np.all(np.isfinite(W2)):
            return float("inf"), 0.0, False

    z1 = X @ W1 + b1
    p_train = softmax(relu(z1) @ W2 + b2)
    perdida = -np.mean(np.log(p_train[np.arange(len(y)), y] + 1e-10))

    p_test = softmax(relu(X_test @ W1 + b1) @ W2 + b2)
    precision = np.mean(np.argmax(p_test, axis=1) == y_test)

    estable = bool(np.isfinite(perdida) and np.isfinite(precision))
    return perdida, precision, estable


# ==================================================
# WIDGET AUXILIAR: CONSOLA DE SALIDA
# ==================================================

class Consola(ttk.Frame):
    def __init__(self, master, height=14):
        super().__init__(master)
        self.texto = tk.Text(self, height=height, wrap="word",
                             font=("Consolas", 10), state="disabled")
        barra = ttk.Scrollbar(self, command=self.texto.yview)
        self.texto.configure(yscrollcommand=barra.set)
        self.texto.pack(side="left", fill="both", expand=True)
        barra.pack(side="right", fill="y")

    def escribir(self, s=""):
        self.texto.configure(state="normal")
        self.texto.insert("end", s + "\n")
        self.texto.see("end")
        self.texto.configure(state="disabled")

    def limpiar(self):
        self.texto.configure(state="normal")
        self.texto.delete("1.0", "end")
        self.texto.configure(state="disabled")


# ==================================================
# APLICACIÓN
# ==================================================

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Laboratorio de Red Neuronal")
        self.geometry("820x640")
        self.minsize(720, 560)

        self.cola = queue.Queue()
        self.after(100, self._procesar_cola)

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        self._tab_decision(nb)
        self._tab_softmax(nb)
        self._tab_entrenamiento(nb)
        self._tab_cuarta_accion(nb)
        self._tab_teoria(nb)

    # ---------- utilidades de hilos ----------
    def _en_hilo(self, tarea, consola, boton=None):
        """Ejecuta `tarea` (devuelve lista de líneas) sin congelar la ventana."""
        if boton is not None:
            boton.state(["disabled"])
        consola.escribir("Calculando...")

        def trabajo():
            try:
                lineas = tarea()
            except Exception as e:  # noqa: BLE001
                lineas = [f"Error: {e}"]
            self.cola.put((consola, boton, lineas))

        threading.Thread(target=trabajo, daemon=True).start()

    def _procesar_cola(self):
        try:
            while True:
                consola, boton, lineas = self.cola.get_nowait()
                for linea in lineas:
                    consola.escribir(linea)
                if boton is not None:
                    boton.state(["!disabled"])
        except queue.Empty:
            pass
        self.after(100, self._procesar_cola)

    # ---------- Pestaña 1: decisión ----------
    def _tab_decision(self, nb):
        f = ttk.Frame(nb, padding=12)
        nb.add(f, text="1. Decisión")

        ttk.Label(f, text="Mueve las necesidades y mira qué acción elige la mascota.",
                  font=("TkDefaultFont", 10, "bold")).pack(anchor="w")

        self.v_hambre = tk.DoubleVar(value=0.6)
        self.v_energia = tk.DoubleVar(value=0.8)
        self.v_abur = tk.DoubleVar(value=0.3)

        for texto, var in [("Hambre", self.v_hambre),
                           ("Energía", self.v_energia),
                           ("Aburrimiento", self.v_abur)]:
            fila = ttk.Frame(f)
            fila.pack(fill="x", pady=4)
            ttk.Label(fila, text=texto, width=14).pack(side="left")
            ttk.Scale(fila, from_=0, to=1, variable=var,
                      command=lambda _=None: self._actualizar_decision()
                      ).pack(side="left", fill="x", expand=True)
            lbl = ttk.Label(fila, width=6)
            lbl.pack(side="left")
            var._lbl = lbl  # etiqueta asociada

        self.lbl_resultado = ttk.Label(f, font=("TkDefaultFont", 16, "bold"))
        self.lbl_resultado.pack(pady=12)

        self.barras = []
        self.lbls_barras = []
        for nombre in ACCIONES:
            fila = ttk.Frame(f)
            fila.pack(fill="x", pady=2)
            ttk.Label(fila, text=nombre, width=10).pack(side="left")
            pb = ttk.Progressbar(fila, maximum=100)
            pb.pack(side="left", fill="x", expand=True)
            lb = ttk.Label(fila, width=22)
            lb.pack(side="left")
            self.barras.append(pb)
            self.lbls_barras.append(lb)

        ttk.Label(f, text="Necesidad = valor directo (Hambre, Aburrimiento) o 1 - energía (Cansancio).\n"
                          "La barra muestra la probabilidad softmax de las tres necesidades.",
                  foreground="gray").pack(anchor="w", pady=8)

        self._actualizar_decision()

    def _actualizar_decision(self):
        hambre = self.v_hambre.get()
        energia = self.v_energia.get()
        abur = self.v_abur.get()
        for var, val in [(self.v_hambre, hambre), (self.v_energia, energia),
                         (self.v_abur, abur)]:
            var._lbl.config(text=f"{val:.2f}")

        necesidades = np.array([hambre, 1 - energia, abur])
        probs = softmax(necesidades[None, :])[0]
        accion = ACCIONES[int(np.argmax(necesidades))]

        self.lbl_resultado.config(text=f"Acción elegida: {accion}")
        for i in range(3):
            self.barras[i]["value"] = probs[i] * 100
            self.lbls_barras[i].config(
                text=f"{probs[i]:.1%}  (necesidad {necesidades[i]:.2f})")

    # ---------- Pestaña 2: softmax ----------
    def _tab_softmax(self, nb):
        f = ttk.Frame(nb, padding=12)
        nb.add(f, text="2. Softmax")

        ttk.Label(f, text="Puntuaciones (Comer, Dormir, Jugar) separadas por comas:"
                  ).pack(anchor="w")
        fila = ttk.Frame(f)
        fila.pack(fill="x", pady=6)
        self.e_punt = ttk.Entry(fila)
        self.e_punt.insert(0, "0.51, 0.49, 0.10")
        self.e_punt.pack(side="left", fill="x", expand=True)
        ttk.Button(fila, text="Calcular", command=self._calcular_softmax
                   ).pack(side="left", padx=6)
        ttk.Button(fila, text="Ejemplos del experimento 2",
                   command=self._ejemplos_softmax).pack(side="left")

        self.con_softmax = Consola(f)
        self.con_softmax.pack(fill="both", expand=True, pady=6)
        self._ejemplos_softmax()

    def _mostrar_softmax(self, puntuaciones):
        probs = softmax(np.array([puntuaciones]))[0]
        self.con_softmax.escribir(f"\nPuntuaciones: {puntuaciones}")
        for nombre, p in zip(ACCIONES, probs):
            self.con_softmax.escribir(f"  {nombre}: {p:.2%}")
        self.con_softmax.escribir(f"  Acción elegida: {ACCIONES[int(np.argmax(probs))]}")

    def _calcular_softmax(self):
        try:
            vals = [float(x) for x in self.e_punt.get().split(",")]
            if len(vals) != 3:
                raise ValueError("Se necesitan exactamente 3 valores.")
        except ValueError as e:
            self.con_softmax.escribir(f"Entrada inválida: {e}")
            return
        self._mostrar_softmax(vals)

    def _ejemplos_softmax(self):
        self.con_softmax.limpiar()
        for p in [[0.51, 0.49, 0.10], [0.55, 0.45, 0.10], [0.49, 0.51, 0.10]]:
            self._mostrar_softmax(p)

    # ---------- Pestaña 3: entrenamiento ----------
    def _tab_entrenamiento(self, nb):
        f = ttk.Frame(nb, padding=12)
        nb.add(f, text="3. Entrenamiento")

        params = ttk.LabelFrame(f, text="Parámetros", padding=8)
        params.pack(fill="x")

        self.s_neu = tk.StringVar(value="6")
        self.s_epo = tk.StringVar(value="1200")
        self.s_tasa = tk.StringVar(value="0.1")
        self.v_cuatro = tk.BooleanVar(value=False)

        ttk.Label(params, text="Neuronas ocultas").grid(row=0, column=0, sticky="w")
        ttk.Spinbox(params, from_=1, to=100, textvariable=self.s_neu, width=8
                    ).grid(row=0, column=1, padx=6)
        ttk.Label(params, text="Épocas").grid(row=0, column=2, sticky="w")
        ttk.Spinbox(params, from_=10, to=10000, increment=100,
                    textvariable=self.s_epo, width=8).grid(row=0, column=3, padx=6)
        ttk.Label(params, text="Tasa de aprendizaje").grid(row=0, column=4, sticky="w")
        ttk.Entry(params, textvariable=self.s_tasa, width=8
                  ).grid(row=0, column=5, padx=6)
        ttk.Checkbutton(params, text="4 acciones (con Bañarse)",
                        variable=self.v_cuatro).grid(row=1, column=0, columnspan=3,
                                                     sticky="w", pady=(6, 0))

        botones = ttk.Frame(f)
        botones.pack(fill="x", pady=8)
        self.btn_entrenar = ttk.Button(botones, text="Entrenar", command=self._entrenar_uno)
        self.btn_entrenar.pack(side="left")
        self.btn_exp3 = ttk.Button(botones, text="Experimento 3: barrido de neuronas",
                                   command=self._exp3)
        self.btn_exp3.pack(side="left", padx=6)
        self.btn_exp4 = ttk.Button(botones, text="Experimento 4: épocas y tasa",
                                   command=self._exp4)
        self.btn_exp4.pack(side="left")
        ttk.Button(botones, text="Limpiar",
                   command=lambda: self.con_train.limpiar()).pack(side="right")

        self.con_train = Consola(f)
        self.con_train.pack(fill="both", expand=True)

    @staticmethod
    def _fmt(neu, epo, tasa, perdida, precision, estable):
        return (f"Neuronas={neu:2d} | Épocas={epo:4d} | Tasa={tasa:.3f} | "
                f"Pérdida={perdida:.4f} | Precisión={precision:.2%} | Estable={estable}")

    def _entrenar_uno(self):
        try:
            neu = int(self.s_neu.get())
            epo = int(self.s_epo.get())
            tasa = float(self.s_tasa.get())
        except ValueError:
            self.con_train.escribir("Parámetros inválidos.")
            return
        cuatro = self.v_cuatro.get()

        def tarea():
            r = entrenar(neu, epo, tasa, cuatro)
            return [self._fmt(neu, epo, tasa, *r) + (" | 4 acciones" if cuatro else "")]

        self._en_hilo(tarea, self.con_train, self.btn_entrenar)

    def _exp3(self):
        def tarea():
            return [self._fmt(c, 1200, 0.1, *entrenar(c, 1200, 0.1))
                    for c in [3, 6, 10, 20]]
        self._en_hilo(tarea, self.con_train, self.btn_exp3)

    def _exp4(self):
        def tarea():
            cfgs = [(100, 0.1), (600, 0.1), (1200, 0.1), (1200, 0.001), (1200, 1.0)]
            return [self._fmt(6, e, t, *entrenar(6, e, t)) for e, t in cfgs]
        self._en_hilo(tarea, self.con_train, self.btn_exp4)

    # ---------- Pestaña 4: cuarta acción ----------
    def _tab_cuarta_accion(self, nb):
        f = ttk.Frame(nb, padding=12)
        nb.add(f, text="4. Cuarta acción")

        ttk.Label(f, text="Agrega 'Bañarse' como cuarta acción (entrada extra: Suciedad)."
                  ).pack(anchor="w")
        botones = ttk.Frame(f)
        botones.pack(fill="x", pady=8)
        ttk.Button(botones, text="Generar 10 ejemplos",
                   command=self._ejemplos_cuatro).pack(side="left")
        self.btn_red4 = ttk.Button(botones, text="Entrenar red 4-6-4",
                                   command=self._entrenar_cuatro)
        self.btn_red4.pack(side="left", padx=6)

        self.con_cuatro = Consola(f)
        self.con_cuatro.pack(fill="both", expand=True)

    def _ejemplos_cuatro(self):
        self.con_cuatro.limpiar()
        X4, y4 = crear_datos(10, cuatro_acciones=True)
        for e, etiqueta in zip(X4, y4):
            self.con_cuatro.escribir(
                f"Hambre={e[0]:.2f}, Energía={e[1]:.2f}, "
                f"Aburrimiento={e[2]:.2f}, Suciedad={e[3]:.2f} "
                f"-> {ACCIONES_4[etiqueta]}")

    def _entrenar_cuatro(self):
        def tarea():
            perdida, precision, _ = entrenar(6, 1200, 0.1, cuatro_acciones=True)
            return ["Red 4 entradas, 6 ocultas y 4 salidas",
                    f"Pérdida: {perdida:.4f}",
                    f"Precisión: {precision:.2%}"]
        self._en_hilo(tarea, self.con_cuatro, self.btn_red4)

    # ---------- Pestaña 5: teoría ----------
    def _tab_teoria(self, nb):
        f = ttk.Frame(nb, padding=12)
        nb.add(f, text="5. Teoría")

        ttk.Button(f, text="Mostrar preguntas y respuestas",
                   command=self._teoria).pack(anchor="w", pady=(0, 8))
        self.con_teoria = Consola(f)
        self.con_teoria.pack(fill="both", expand=True)
        self._teoria()

    def _teoria(self):
        c = self.con_teoria
        c.limpiar()

        entrada = np.array([[0.8, 0.2, 0.5]])
        pesos = np.array([[0.7], [-0.5], [0.3]])
        sesgo = 0.1
        resultado = entrada @ pesos + sesgo
        c.escribir("1. PESOS Y SESGOS")
        c.escribir("Los pesos determinan la influencia de cada entrada.")
        c.escribir("El sesgo desplaza el resultado de la suma ponderada.")
        c.escribir(f"Ejemplo numérico: {resultado[0, 0]:.2f}\n")

        energia = 0.2
        c.escribir("2. CANSANCIO")
        c.escribir("Se calcula como 1 - energía para invertir la escala.")
        c.escribir(f"Energía: {energia} | Cansancio: {1 - energia}\n")

        valores = np.array([[-2.0, 0.5, 2.0]])
        c.escribir("3. RELU Y SOFTMAX")
        c.escribir(f"ReLU: {relu(valores)}")
        c.escribir(f"Softmax: {np.round(softmax(valores), 4)}")
        c.escribir("ReLU elimina valores negativos.")
        c.escribir("Softmax convierte puntuaciones en valores que suman 1.\n")

        esperadas = np.array([0, 1, 2, 0, 1])
        predichas = np.array([0, 1, 2, 0, 0])
        c.escribir("4. PRECISIÓN ALTA")
        c.escribir(f"Precisión de ejemplo: {np.mean(esperadas == predichas):.2%}")
        c.escribir("Una precisión alta puede ser engañosa si las etiquetas "
                   "son artificiales o no representan situaciones reales.")


if __name__ == "__main__":
    App().mainloop()
